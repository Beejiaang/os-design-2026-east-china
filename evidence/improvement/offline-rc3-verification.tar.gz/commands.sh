set -eu
git clone --branch feat/a-offline-review-package ./project-9fc805006ea2.bundle review
cd review
test "$(git rev-parse HEAD)" = "9fc805006ea228e930e705319ff171709c770934"
python3 -m venv .venv
. .venv/bin/activate
PIP_NO_INDEX=1 PIP_FIND_LINKS="$PWD/../wheels" python -m pip install -e '.[report]'
python -m pip check
python -m runner doctor
OSDESIGN_INTEGRATION=1 python -m unittest discover -s tests -v
python experiments/run_pipeline.py --output results/first
test -z "$(git status --porcelain)"
