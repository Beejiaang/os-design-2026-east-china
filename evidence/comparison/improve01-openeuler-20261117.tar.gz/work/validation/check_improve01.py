import json, math, hashlib
from pathlib import Path
from workloads.dataset import check_output, sha256
from analysis.core import analyze
from jsonschema import Draft202012Validator, FormatChecker
root=Path('results/tools')
s=json.loads((root/'summary.json').read_text()); assert s['complete'] and s['valid_count']==54
rows=[json.loads(l) for l in (root/'comparison.jsonl').read_text().splitlines()]
reference=json.loads((root/'reference.json').read_text())
validator=Draft202012Validator(json.loads(Path('schemas/run-1.1.schema.json').read_text()),format_checker=FormatChecker())
for r in rows:
 p=Path(r['artifacts']);assert r['source']=='measured' and r['status']=='success'
 assert r['functional_ok'] and r['cleanup_ok'] and r['quota_verified']
 assert check_output(p/'stdout.log',reference) and sha256(p/'stdout.log')==r['stdout_sha256']
 if r['tool']=='project':validator.validate(json.loads((p/'result.json').read_text()))
 if not r['warmup']:assert math.isfinite(r['outer_seconds']) and r['outer_seconds']>=0
assert len(rows)==54 and sum(not r['warmup'] for r in rows)==45
for batch in (root/'hyperfine').iterdir():
 export=json.loads((batch/'hyperfine.json').read_text())['results'][0]
 assert len(export['times'])==5
 assert all(c==0 for c in export['exit_codes'])
pipeline=analyze(Path('results/pipeline/experiment'))
assert pipeline['complete'] and len(pipeline['eligible'])==15 and pipeline['finalized_count']==18
print(json.dumps({'tools_valid':54,'tools_nonwarmup':45,'pipeline_valid':18,'pipeline_eligible':15,'groups':s['groups']},indent=2))
