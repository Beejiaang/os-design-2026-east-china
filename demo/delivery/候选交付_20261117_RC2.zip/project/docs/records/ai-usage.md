# AI 辅助工作记录

## 已发生的工作

| 日期 | 工具／模型 | 使用范围 | 产出 | 验证情况 |
|---|---|---|---|---|
| 2026-10-20 | Codex；本次会话未提供可核验的具体模型版本标识 | 汇总既有选题讨论，整理规则依据、技术来源、方向比较与协作模板 | 本仓库初始文档 | 已核对本地规则摘录和文件内容；尚未进行任何项目实机性能或正确性测试 |
| 2026-10-20 | Codex | 根据团队要求将仓库定位调整为完整参赛项目协作仓库，检查文档链接并上传初始资料、建立选题讨论入口 | README、协作说明及 GitHub 初始提交 | 核验远端文件与本地版本；本轮未开发项目代码 |
| 2026-10-21 | Codex | 根据团队选择方向 A 的决定，安排 CPU 配额测试项目范围、成员职责、学习任务与截止计划 | docs/history/project-plan.md、README | 核对章程第 2 页与平台日期字段差异，记录待核实事项；逐文件核验上传内容；尚未进行项目实机测试 |

| 2026-10-21 | Codex | 明确初稿交付时间、验收清单、投入前提及 11 月 1 日进度检查，区分 11 月 8 日初稿与 11 月 15 日核心版本 | docs/history/project-plan.md、README | 核验日期与已有排期一致，回读远端文件检查上传内容；项目功能仍待实施 |

本表是摘要，不能代替赛事要求的完整过程记录。后续保留必要交互记录，公开前移除无关个人信息和凭据。模型名称应按实际使用界面或记录填写，不猜测版本。

### 2026-11-16：成员 A 实现

- 工具：Codex；根据用户要求控制已准备环境并完成 A 的工作
- 生成内容：runner、collector、兼容前提接口、计算探针、测试、使用与设计说明
- 实际执行：代理通过 SSH 在 openEuler 24.03 LTS-SP4 / Python 3.11.6 执行 8 项测试及 12 次三档实验；异常、超时与脱离会话子进程清理测试通过，保存原始数据及日志
- 修正：首轮 WSL 测试发现无本地配额时叶节点 cpu.max 可缺失，补充父节点控制器核验后复测通过；Windows 不支持 resource，调整为仅 Linux worker 运行时导入
- 人工复核：用户/队友代码讲解、独立复现和 B/C 交叉验收尚待完成，不将代理执行等同人工验收
- 证据：[验收记录](../validation/member-a-validation.md)、`evidence/member-a/openeuler-20261116.tar.gz`；未自动上传 GitHub 或正式比赛平台

### 2026-11-16：按计划推进第二步

- 范围：A 的基线兼容前提核验、CLI、干净源码复验及阶段进度登记
- 修正：缺失 environment/visible_limits 原先可能触发异常，缺少 warmup/exit_code 或状态类型不正确原先可能被接受；新增明确拒绝条件
- 执行：openEuler 上从干净提交检出，9 项测试及 12 次新实验通过；7 类兼容 CLI 结果符合预期
- 证据：`evidence/member-a/stage2-openeuler-20261116.tar.gz`；没有将同一代理复验标记为非实现者独立验收，没有替 B/C 填写完成

### 2026-11-16：可靠性补强、统一规则与授权推送

- 用户授权：继续可靠性工作，统一队友使用 Agent 时的项目口径与交接规则，全部完成后推送仓库
- 实现：SIGINT/SIGTERM 记录与清理、执行器丢失后的看门狗和显式恢复、worker 崩溃与快照损坏处理、最终索引/完整性状态、run 1.1 协议和可选格式检查
- 规则：AGENTS.md、project-contract、data-contract、agent-handoff、角色启动任务、PR 交接字段；保留 B/C 和人工作业的待验收状态
- 修正：新故障测试暴露 RemainAfterExit 不能为 active/exited 状态提供所需兜底，改为测量后 worker 等待回收；复验通过。worker 崩溃测试原重复两次导致后续任务等待，不是第一次错误未捕获，已把该案例限定为单次
- 实际验证：干净提交 9c075aa 上 openEuler 17 项测试、12 次正常实验；保留 5 份故障注入最终记录并明确排除性能样本；17 份最终记录符合 1.1 schema
- 证据：stage3-openeuler-20261116.tar.gz、docs/validation/member-a-validation.md；模型版本未从不可核验信息猜测，人工/队友复验尚未完成

### 2026-11-17：跨 A/B/C 接通正式数据任务与报告

- 授权范围：用户明确要求先不局限成员职责，全盘按照计划推进；没有延伸为代办报名、发送队友消息或比赛提交
- 工具：Codex；代码与技术文档由代理生成和修正，人工理解/复验仍待团队完成
- 实现：固定种子 CSV、单进程 count/sum、SQLite 独立参考校验、完整实验编排、run 1.1 严格消费/完整性/样本排除、配置对照、兼容历史复核规则、离线 HTML 点图/追溯及演示提纲；未更改 run/config 协议或 A 的测量语义
- 验证：openEuler 与 WSL 分别跑三轮各 54 次真实执行；每环境 45 条非预热通过独立校验、9 条预热排除，不跨环境合并基线。目标机完整测试及版本见集成验证；正常复测/受控变慢与四类负向前提均留证
- 修正：元数据为 JSON 数组时原分析可能在记录问题后仍访问 .get；改为先验证再接纳，并补损坏元数据测试。跨版本离线依赖首装缺 typing_extensions，补齐后通过。目标机旧 DHCP 网段由用户重启恢复，再更新已备份的本机 SSH 别名
- 证据：[集成验证](../validation/pipeline-validation.md)、evidence/integration 的两个归档及 SHA256SUMS；原始输入按固定参数可复建，归档不含大 CSV
- 限制：探索性阈值未证明普遍准确率/统计显著性；报告浏览器视觉验收未完成；非实现者、视频/PPT、同类实测与赛事流程仍待推进；本轮未推送、建 PR、共享合并或正式提交

## 后续记录模板

### 2026-11-17：演示初稿与人员复验交接

- 用户继续授权按计划推进，代理制作十页答辩工作稿、原生图表/表格、备注来源与讲解、20问、人员复验指南/空白模板及固定源码交付包，没有自动填写人工验收或发送材料
- 采用 Presentations 技能及第一方 Artifact Session；封面使用内置 image_gen 生成概念处理器配图，原图、提示词和用途记录在 demo/assets，未冒充硬件照片或实验截图
- 演示数值来自既有400万行原始实验，保留8d76aed测量/25b7f32分析/57c865e源码快照说明。图表嵌入工作簿为本次完整字面数值快照，没有虚构来源Excel公式
- 新的openEuler源码检出和全新venv完成源码可编辑离线安装、29项测试（0跳过）及3次小试，pip check与命令入口通过；仍是同一代理，不当作队友/第二台机器复现
- 原生PowerPoint打开/最终答辩规格、报告浏览器视觉、真实视频与平台状态未验收。PPT和复验包是当前工作稿/待人员执行交付，不代表已发送、录制、托管或正式提交
- 本轮未改runner/collector/负载/分析逻辑，原始测量数据没有重标；本地提交并保留原分支，未推送/建PR/共享合并

### 2026-11-17：同类工具对照与规则边界扩展

- 用户在了解后续事项后明确要求“继续推进”，本轮按同类对照与规则验收执行，仍不代办报名/通信/赛事提交
- 代理新增对照脚本、服务快照辅助程序、固定规则验证套件、部分额外处理参数与必要测试；GNU time 从官方 HTTPS 源码下载，在普通用户目录编译，未复制其实现进入工程
- 干净源码 8d76aed 在目标 openEuler 完成 36 次工具对照与 48 次规则实验；84 次实际执行均成功/正确/清理通过，72 条非预热、12 条预热明确区分；五类派生负向前提拒绝比较，原始文件未修改
- 源码 25b7f32 添加已观察范围敏感性及 HTML 提示，未改 15% 阈值、最少样本或原 verdict。对原始数据重算后五项规则输出与比值保持一致；最终 29 项目标机测试全部通过，0 跳过
- 发现实际 worker 的 wall 还含快照保存、文件打开、等待及末次采样，对协议/设计说明作事实细化；没有移动计时点、修改单位/runner 哈希或重标旧数据。GNU 与本队的计时精度/边界差异不能用于速度排名
- 修正 GNU 时间文件为空时应明确拒绝；补充解析与配额缺失拒绝、输出保持正确、阈值相等和范围敏感的夹具测试
- 产物：[方法与贡献边界](../implementation/tool-comparison.md)、[扩展验证](../validation/comparison-validation.md)、evidence/comparison 的归档及哈希；人工交叉复验/更广统计验收/浏览器视觉/视频与平台工作仍待推进
- 本轮本地提交、保留原分支，未推送/建 PR/共享合并/正式比赛提交；自动测试与生成内容不代表成员已完成人工贡献或理解验收

### 2026-11-16：文件分区整理

- 按用户要求将文档归入 project、contracts、implementation、validation、handoff、records、history，新增 docs 导航和工程分区规则，更新全部当前文档链接与 Agent 路径
- 明确 workloads、experiments、demo 的用途及待交付状态，保留 src、schemas、examples、证据归档和正式结果路径
- 本机工作区另分传输包、日志、私有备份和历史复验副本；原始规则 PDF 和虚拟机环境未移动
- 检查内容为链接、旧路径残留、Git 差异和入口烟测；本次未变更运行时代码，不重复声称做了新一轮 17 项系统测试

- 日期、任务或 Issue：
- 工具、模型与可确认的版本：
- 输入问题与使用目的：
- 生成内容所在文件和提交：
- 人工修改及负责队员：
- 测试方式与原始结果：
- 接受或拒绝生成建议的原因：
- 交互记录存放位置（公开内容应先检查）：

### 2026-11-17 候选交付与仓库整理

- 用户明确排除人工验收和视频演示，授权推进其他事项。代理整理正式设计与测试稿、检查原生PPT、准备冻结复验及候选打包，不替人员认领贡献。
- 十页PPT在原生PowerPoint逐页打开检查，无修复提示，图表标签和版式正常，文件哈希未变。
- Word生成器以Markdown为源。打包的render_docx.py因Windows缺少LibreOffice失败，记录错误后使用原生Word经UI导出PDF，再用bundled Poppler逐页栅格检查，修正继承标题线和末尾孤页，最终七页。
- 正常Git凭据推送集成分支成功；PR/合并与冻结目标机证据另见候选验证。未修改运行逻辑和既有原始记录。
- HTML浏览器file协议操作此前被自动审批拒绝，未绕过；报名、导师、人员事实及官方GitLab未提供，保持缺项，不冒充已提交。

### 2026-11-17 改进任务 2：固定样本阈值矩阵

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/02-threshold-matrix`，基于 `54ef928`。
- 产物：docs/validation/comparison-validation.md、evidence/comparison/threshold-matrix-20261117.json、evidence/comparison/SHA256SUMS。人工负责成员未填写。
- 检查及限制：重新分析六场景共 48 条记录；15 格可比，逐格保留 run_id；Markdown 链接检查通过。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 1：hyperfine 三档实测对照

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/01-hyperfine`，基于 `6f6fb7d`。
- 产物：docs/implementation/tool-comparison.md、docs/validation/comparison-validation.md、evidence/comparison/improve01-openeuler-20261117.tar.gz、evidence/comparison/SHA256SUMS。人工负责成员未填写。
- 检查及限制：干净源码 d8a331e：openEuler 29 项0跳过；默认完整流程18次；对照54次逐份SQLite/配额/清理通过；pip check通过。证据 evidence/comparison/improve01-openeuler-20261117.tar.gz。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 3：评审三份材料导读

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/03-reviewers-guide`，基于 `4f8ca84`。
- 产物：docs/reviewers-guide.md、README.md。人工负责成员未填写。
- 检查及限制：本地 Markdown 链接检查通过；导读正文为一张五行索引表。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 4：可追溯开发时间线

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/04-timeline`，基于 `31f6f28`。
- 产物：docs/history/timeline.md、README.md。人工负责成员未填写。
- 检查及限制：git log --all 核对日期和提交；本地文档与 evidence 链接检查通过。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 5：教学观察思考题与报告模板

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/05-teaching-observations`，基于 `1d54111`。
- 产物：docs/implementation/teaching-experiments.md。人工负责成员未填写。
- 检查及限制：原有 bash 命令逐字保留；数值核对集成验证表；本地链接检查通过。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 6：最小纯单元与协议 CI

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/06-ci`，基于 `4ccef58`。
- 产物：.github/workflows/ci.yml。人工负责成员未填写。
- 检查及限制：workflow 已准备；无推送授权，GitHub 未运行。最终本地/目标机等价命令日志统一归档到 P0 验证记录；不把跳过系统项计为通过。tasklist 中任务6所指 ruff 实为任务17，本轮不提前机械修改源码。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 7：仓库体积及大文件评估

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/07-repository-size`，基于 `c65611a`。
- 产物：docs/project/platform-readiness.md。人工负责成员未填写。
- 检查及限制：git count-objects -vH 与 git ls-files -z + stat 实测；所有表项按字节记；未迁移文件或改写历史。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 8：材料版本与哈希自动清单

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/08-material-manifest`，基于 `1e1a83f`。
- 产物：scripts/material_manifest.py、docs/validation/material-versions.md、docs/validation/improvement-p0-validation.md、evidence/improvement。人工负责成员未填写。
- 检查及限制：脚本源码a4f4c04；两次生成逐字节一致、冻结材料错误哈希夹具被拒绝；openEuler29项0跳过+完整流程18次+pip check通过。本地3.12纯测试20通过9跳过。见docs/validation/improvement-p0-validation.md。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 9：GitLab 命名与描述文案草稿

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/09-gitlab-copy`，基于 `29b660f`。
- 产物：docs/project/platform-readiness.md。人工负责成员未填写。
- 检查及限制：核对用户提供技术方案第四部分本地缓存；必需五项字段齐全，保留人工填空；链接检查通过。 不将代理检查改标人工验收。

### 2026-11-17 P0统一交接

- 整理9项任务的本地分支/提交、两轮openEuler实测和CI限制；更新导航与最新接续段，历史交接保留原样。P1尚未执行；没有推送、PR、合并、tag或人工事项代办。
- 最后仅变更文档与材料表，执行本地链接、全部evidence哈希与RC1材料哈希检查；不重复声称新增运行源码验证。

### 2026-11-17 改进任务 12：重复次数与预热依据

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/12-sampling-rationale`，基于 `44dbddd`。
- 产物：docs/implementation/pipeline.md。人工负责成员未填写。
- 检查及限制：文档事实核对与本地链接检查；未更改运行代码。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 15：README三行状态头

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/15-readme-status`，基于 `0df6e0d`。
- 产物：README.md。人工负责成员未填写。
- 检查及限制：文档事实核对与本地链接检查；未更改运行代码。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 16：资源计时和完成状态统一术语

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/16-glossary`，基于 `be85834`。
- 产物：docs/contracts/glossary.md、README.md、docs/implementation/pipeline.md、docs/implementation/member-a.md、docs/implementation/system-design.md、docs/implementation/tool-comparison.md。人工负责成员未填写。
- 检查及限制：文档事实核对与本地链接检查；未更改运行代码。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 19：核心冻结后变更规则

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/19-freeze-policy`，基于 `b0aa997`。
- 产物：AGENTS.md。人工负责成员未填写。
- 检查及限制：文档事实核对与本地链接检查；未更改运行代码。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 17：Ruff默认规则与CI接入

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/17-ruff`，基于 `0e30e7f`。
- 产物：pyproject.toml、.github/workflows/ci.yml、src/report/html.py、tests/test_member_a.py。人工负责成员未填写。
- 检查及限制：Ruff0.17.5默认E4/E7/E9/F规则通过；只删除一个未用import及将两个lambda机械改成def。本地29项20通过9跳过；因src改动，目标机全量验证在本轮证据记录中补齐，未据此宣称目标机通过。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 18：复用report extra并加入开发检查

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/18-extras`，基于 `f96e456`。
- 产物：pyproject.toml、docs/implementation/pipeline.md。人工负责成员未填写。
- 检查及限制：Windows3.12 editable安装.[dev]及pip check通过；report extra保留为唯一jsonschema声明。目标机全量验证待本轮归档；不改变执行器依赖。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 11：Linux负载旁路采样

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/11-host-load`，基于 `5e0a9d9`。
- 产物：src/collector/host_load.py、src/runner/core.py、tests/test_host_load.py、docs/contracts/data-contract.md。人工负责成员未填写。
- 检查及限制：新增3项采样/异常/写入失败单测；本地32项23通过9跳过，Ruff通过；目标机全量和完整流程按此源码单独复验归档。environment.json附加证据格式linux-load-v1，run/config不变，采样不参与判定。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 13：历史比较观察范围区间条

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/13-range-visualization`，基于 `1bde76a`。
- 产物：src/report/html.py、tests/test_range_bar.py。人工负责成员未填写。
- 检查及限制：新增2项SVG几何/缺失数据测试；本地34项25通过9跳过，Ruff通过。原compare未改；目标机全量及真实数据重生成截图待本轮验证归档。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 14：全src长度分帧源码指纹

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/14-source-fingerprint`，基于 `2d60a88`。
- 产物：src/runner/core.py、tests/test_source_fingerprint.py、schemas/run-1.1.schema.json、docs/contracts/data-contract.md、docs/implementation/member-a.md。人工负责成员未填写。
- 检查及限制：新增2项路径/嵌套文件/内容分界测试；本地36项27通过9跳过，Ruff通过。src-py-v2算法版本在域分隔和协议中显式说明；run1.1字段形状不变，新旧指纹不可混比。目标机逐源码复验待归档。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 10：三种规模独立正确性及内存实测

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/10-scale-sweep`，基于 `0be73a7`。
- 产物：experiments/scale_sweep.py、tests/test_scale_sweep.py、docs/validation/improvement-p1-validation.md、evidence/improvement。人工负责成员未填写。
- 检查及限制：bb288cb：openEuler37项0跳过+默认18次完整流程+pip check+Ruff；规模扫描54次逐份SQLite/配额/内存/清理通过。六个代码任务分别复验的日志、源码与限制见docs/validation/improvement-p1-validation.md。 不将代理检查改标人工验收。

### 2026-11-17 P1逐提交目标机验收与统一交接

- 按用户“继续下一轮”授权完成任务10–19，保留各命名分支。具体源码f96e456/5e0a9d9/1bde76a/2d60a88/0be73a7/bb288cb分别全量验证，测试数29/29/32/34/36/37且0跳过；六轮默认流程108次及规模扫描54次，未混作性能基线。
- 新增源码/采样/区间/内存检查由代理实现；命令、原始结果及来源哈希归档在evidence/improvement。真实区间HTML在Edge无头模式截图并检查，不把夹具当真实跨阈值样本。
- 算法版本src-py-v2扩大覆盖至全部src，明确旧数据不迁移、新旧摘要不直接可比；旁路loadavg为Linux来宾信息，不进入判定。未声称统计准确率、普遍线性、生产可靠性或教学效果。
- 文档、术语、冻结规则与材料表更新，旧RC1二进制未重生成。本轮无推送/PR/合并/tag/赛事提交，未替人员认领贡献或代办视频和人工验收。

### 2026-11-17 改进任务 20：变更日志与候选标签建议

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/20-changelog`，基于 `19b223f`。
- 产物：CHANGELOG.md、README.md、docs/project/platform-readiness.md。人工负责成员未填写。
- 检查及限制：读取Git历史、pyproject旧版本及现有注释标签核对；本地Markdown链接检查通过。仅文档变更，不重跑目标机测试，不创建或修改标签。 不将代理检查改标人工验收。

### 2026-11-17 改进任务 21：交付改名条件复核并保持现状

- 工具：Codex 代理；按用户指定 tasklist 执行，分支 `improve/21-delivery-name-policy`，基于 `7360e66`。
- 产物：docs/project/platform-readiness.md。人工负责成员未填写。
- 检查及限制：实际重测tracked字节36,731,608，对象库测量已记入平台准备；未发生大文件迁移，按清单条件不执行改名。仅文档及链接检查，无运行代码改动。 不将代理检查改标人工验收。

### 2026-11-17 P2统一交接与清单收尾

- 用户授权继续下一轮；基于19b223f，仅处理任务20/21，建立独立串联分支，CHANGELOG按已有Git记录回填，采用Keep a Changelog分类与未发布区。
- 发现本地既有注释标签v0.1.0-rc.1，核对tag对象与目标54ef928；没有创建原清单建议的同义标签v0.1.0-rc1，没有改变或推送既有标签，未查询远端状态。
- 受版本管理文件与Git对象库实测未达100MB，未发生任务7迁移，故任务21按条件不执行改名；不把条件跳过记成英文重命名已完成。
- 检查Git差异、文档链接、全部现有证据/RC1声明哈希及main/tag不变；更新进度与材料对应表。无运行代码变更，不宣称本轮新增目标机测试；没有代办人工、视频或平台提交。

### 2026-11-17 RC2候选材料同步

- 按用户继续下一轮的授权，基于7ef8f88整理RC2九页报告及十二页PPT，原测量版本分别注明；没有替成员认领人工贡献，没有执行视频或报名/平台事项。
- 使用documents/pdf/presentations技能：bundled Python生成DOCX，render_docx因缺少LibreOffice失败；保留错误后通过已安装Office兼容接口导出WPS PDF，Poppler逐页检查并修正末页孤段。
- Artifact Session构建与逐页渲染，修复图片嵌入、标签字号和字体声明；finalizer核对原生表格、图表与新字面数据工作簿、结构/字体并重新导入渲染。未声称原生PowerPoint已检查或保留来源公式。
- 新manifest与旧RC1独立保存，拓展材料表读取多个声明，打包工具增加显式RC2标记。只改材料工具和文档，不改执行/分析逻辑，不冒充新目标机实测。
