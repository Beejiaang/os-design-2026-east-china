"""Check three finalized experiments produced by the public pipeline."""
import json
import sys
from pathlib import Path

from analysis.core import analyze, compare


def main(baseline, repeat, changed):
    summaries = [analyze(Path(directory) / "experiment") for directory in (baseline, repeat, changed)]
    for summary in summaries:
        assert summary["complete"] and len(summary["eligible"]) == 15
    envs = [summary["eligible"][0]["environment"] for summary in summaries]
    assert envs[0]["visible_limits"][0]["path"] != envs[1]["visible_limits"][0]["path"]
    assert envs[0]["affinity"] == envs[1]["affinity"] != envs[2]["affinity"]
    matched, rejected = [compare(summaries[0], other) for other in summaries[1:]]
    for comparison in (matched, rejected):
        assert {r["quota_percent"] for r in comparison["comparisons"]} == {None, 50, 100}
    assert all(r["wall_ratio"] is not None for r in matched["comparisons"])
    assert all(r["wall_ratio"] is None and "environment metadata differs" in r["reasons"]
               for r in rejected["comparisons"])
    print(json.dumps({"scopes": [e["visible_limits"][0]["path"] for e in envs],
                      "affinity": [e["affinity"] for e in envs],
                      "repeat": matched, "changed": rejected}, indent=2))


if __name__ == "__main__":
    main(*sys.argv[1:])
