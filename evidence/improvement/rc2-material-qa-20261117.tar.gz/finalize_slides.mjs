import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import fs from 'node:fs/promises';
const cfg=JSON.parse(await fs.readFile(new URL('./runtime.json',import.meta.url),'utf8'));
const root=fileURLToPath(new URL('../../',import.meta.url));
const SKILL="C:/Users/Ho'lo/.codex/plugins/cache/openai-primary-runtime/presentations/26.1116.12020/skills/presentations";
const {finalizePresentation}=await import(pathToFileURL(path.join(SKILL,'container_tools/artifact_tool_utils.mjs')).href);
const result=await finalizePresentation({workspaceDir:root,candidatePath:path.join(root,'work/rc2/slides/draft-rc2.pptx'),finalPath:path.join(root,'demo/presentation/答辩材料_RC2.pptx'),pythonExecutable:cfg.python,integrityValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit','--require-native-table-slide','4','--require-native-table-slide','7','--require-native-table-slide','8'],explicitTotalSlideCount:12,requiredNativeTableOwnerSlides:[4,7,8],requiredNativeChartOwnerSlides:[6],materializeLiteralChartWorkbooks:true,fontPolicy:{basis:'design',families:['Microsoft YaHei']},verifyArtifactToolImport:true,receiptPath:path.join(root,'work/rc2/slides/validation.json')});
console.log(JSON.stringify(result));
