import json
from pathlib import Path
from analysis.core import analyze, compare
from report.html import render
from workloads.dataset import check_output, sha256
from experiments.compare_tools import parse_time, quota_matches
from jsonschema import Draft202012Validator, FormatChecker

root = Path.cwd()
tools = root / 'results/tools'
regression = root / 'results/regression'
validator = Draft202012Validator(json.loads((root / 'schemas/run-1.1.schema.json').read_text()), format_checker=FormatChecker())
summary = json.loads((tools / 'summary.json').read_text())
assert summary['complete'] and summary['valid_count'] == 36 and summary['parent_limits_equal']
reference = json.loads((tools / 'reference.json').read_text())
comparison = [json.loads(line) for line in (tools / 'comparison.jsonl').read_text().splitlines()]
assert len(comparison) == 36
for row in comparison:
    directory = Path(row['artifacts'])
    assert row['functional_ok'] and row['cleanup_ok'] and row['quota_verified']
    assert check_output(directory / 'stdout.log', reference)
    assert sha256(directory / 'stdout.log') == row['stdout_sha256']
    if row['tool'] == 'project':
        record = json.loads((directory / 'result.json').read_text())
        validator.validate(record)
        assert record['git_dirty'] == ''
    else:
        snapshot = json.loads((directory / 'snapshot.json').read_text())
        assert quota_matches(snapshot, row['quota_percent'])
        assert parse_time(directory / 'time.txt')['exit_code'] == 0
old = json.loads((regression / 'validation.json').read_text())
assert old['data_checks_passed'] and old['negative_checks_passed'] and old['measured_run_count'] == 48
baseline = analyze(regression / 'baseline/experiment')
reviews = []
for case in old['outcomes']:
    name = case['scenario']
    current = analyze(regression / name / 'experiment')
    assert current['complete'] and len(current['eligible']) == 7
    comparison = compare(baseline, current)
    actual, previous = comparison['comparisons'][0], case['comparison']['comparisons'][0]
    assert actual['wall_ratio'] == previous['wall_ratio'] and actual['verdict'] == previous['verdict']
    render(current, regression / name / 'history-with-sensitivity.html', comparison)
    reviews.append({'scenario': name, **actual})
for path in regression.glob('*/experiment/*/result.json'):
    row = json.loads(path.read_text())
    validator.validate(row)
    assert row['status'] == 'success' and row['cleanup_ok'] and row['git_dirty'] == ''
result = {'kind':'comparison-evidence-check-v1','tool_executions':36,'regression_executions':48,
          'nonwarmup_tool_samples':30,'nonwarmup_regression_samples':42,
          'raw_run_1_1_schema_checked':66,'review_decisions_unchanged':True,'reviews':reviews}
(root / 'work/validation/review-checks.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
