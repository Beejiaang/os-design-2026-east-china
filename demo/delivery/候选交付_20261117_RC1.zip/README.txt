候选交付 RC1，未人工验收，未含正式视频或赛事接收凭据
源码提交 30e6a311025600b78f10de98d3e2d5ae35e9173e
运行：先读 project/README.md 与 project/docs/validation/peer-reproduction.md
源码快照可直接检出运行，Git 历史可用 git clone 包内 bundle 文件恢复
wheels 仅对应 Linux x86_64 CPython 3.11，不配置系统权限
离线安装：在 project 目录执行 python3 -m pip install --no-index --find-links ../wheels -e '.[report]'
文件完整性：核对 MANIFEST.json 中各文件 SHA256；哈希不证明正式提交或人工验收
