# 原生工具对照与回归规则扩展验证

日期：2026-11-17，Asia/Shanghai；由同一代理在已有目标虚拟机执行，不是非实现者验收。对照方法和贡献边界见 [同类工具实测说明](../implementation/tool-comparison.md)。

## 源码、环境与计划

- 基于 `d649f7f`，本轮分支 `feat/b-comparison-validation`；测量源码为干净提交 `8d76aed0b4a619c7c0d6f6d09881b5bbfbae0934`。
- 最终派生诊断/报告源码 `25b7f32`：追加已观察范围敏感性，修复 GNU time 指标文件为空时的错误提示；没有修改原判定规则或重标原始测量提交。
- 复验检出：`/home/holo/projects/osdesign-comparison-20261117`；目标 openEuler 24.03 LTS-SP4、内核 6.6.0-159.4.3.154.oe2403sp4.x86_64、Python 3.11.6、4 vCPU、systemd 255。实际环境、依赖、提交、命令/日志在证据中。
- 固定 400 万行、请求 1000 组、种子 20261117，输入 SHA256 为 `e6020e6dff2ab42b22c34ba233f8de438928ff546f1771c73dffc5cd364d0064`；输入生成与 SQLite 独立参考计算不计入负载时间。
- 对照使用同一输入/源码/输出、三档配额和用户服务父级。扩展规则实验只使用 100% 单逻辑 CPU 配额，不与旧两百万行实验混合成基线。
- 未改 GPU 功率、主机资源、安全策略或其他服务。没有主动施加宿主机干扰；保留各场景执行前的真实 `/proc/loadavg`。采样未覆盖温度、频率、完整宿主机负载，不能排除所有干扰。

## 实际命令与检查

下文 python3 实际为 `~/projects/osdesign-venv/bin/python`：

```bash
PYTHONPATH=src OSDESIGN_INTEGRATION=1 python3 -m unittest discover -s tests -v
python3 experiments/compare_tools.py --output results/tools --time-binary ~/projects/comparison-tools/time-install/bin/time
python3 experiments/validate_regression.py --output results/regression
PYTHONPATH=src:. python3 work/validation/review_comparison_evidence.py
```

初始源码的 28 项目标机测试全部通过。最终诊断源码 25b7f32 的 **29 项全部通过，0 跳过**；包括 A 的系统异常/恢复测试、B/C 的负载/结构/正确性、GNU 时间解析、实际控制快照核验及敏感性公式。后者含中位数恰好等于 15% 时不触发、观察范围跨过阈值时敏感、稳定高于阈值时不敏感的临时夹具，不将夹具当真实性能数据。

### 同类工具：36 次

本队与 GNU time + systemd-run 组合每档各一次预热、五次测量；预热先行，随后方法/配额按固定种子混排，串行执行。36 次均成功，输出逐份与 SQLite 参考一致，实际配额通过核验；可见父级限制一致，清理核验全部通过。输入与负载文件运行前后哈希一致。**30 个非预热样本用于描述性对照，6 个预热排除**。

GNU time 1.10 在普通用户目录编译，无全局安装；保留构建日志、工具版本、可执行文件 SHA256、源码下载 SHA256 与每次原生 argv/标准输出/时间原文/服务内快照/清理结果。本队为 GNU 命令补充的验证脚本没有算成 GNU 原生功能。量化中位数表及不同计时范围见同类工具说明，不输出速度排名。

### 规则扩展：48 次

六个场景在开始前写入 plan.json：基线、正常复测 1、额外处理前 5% 输入、额外处理前 15%、额外处理前 25%、正常复测 2。每场景一次预热、七次测量；阈值仍为先前固定的 15%，每侧最少五条。没有看结果再调阈值。场景顺序固定，前后两组正常复测观察漂移；未随机交错场景，不能据此排除时间顺序混杂。

额外处理使用同一个聚合函数处理输入前缀，仅最后的额外结果被丢弃，最终 stdout 仍是完整输入的正确聚合。源码哈希和 extra 参数组成版本标识；工作量百分比是受控参数，不保证相同百分比的 wall 增长。它不是实际线上退化事故。

48 次最终记录全部 success、配额/清理/独立正确性通过；**42 个非预热样本进入比较，6 个预热排除**。当前原始记录与同类对照中的 18 份 A 记录合计 66 份，均通过 run 1.1 schema 验证。另 18 份原生工具记录使用独立对照格式，没有冒充 run 1.1。

| 场景 | 每侧测量数 | wall 中位数比 | 既定规则结果 | 观察范围比值下界—上界 | 本次范围跨阈值 |
|---|---:|---:|---|---|---|
| 正常复测 1 | 7 | 1.0000 | no_threshold_signal | 0.9997—1.0320 | 否 |
| 额外 5% | 7 | 1.0640 | no_threshold_signal | 1.0317—1.0641 | 否 |
| 额外 15% 边界样本 | 7 | 1.1598 | slowdown_needs_review | 1.1594—1.1599 | 否 |
| 额外 25% | 7 | 1.2557 | slowdown_needs_review | 1.2552—1.2560 | 否 |
| 正常复测 2 | 7 | 0.9999 | no_threshold_signal | 0.9997—1.0001 | 否 |

5% 变体确实增加了工作量，但本次增长未达到预设阈值，所以没有提示；这说明规则对低于阈值的变化不会报警，不能声称“任何退化都能检出”。15% 变体的实测中位数略超过阈值，本次所有观测范围也在阈值上侧；没有人为制造范围跨阈值或把它标为敏感。其他环境/更多样本可能不同。

最终诊断根据已有 min/max 计算当前最小/基线最大到当前最大/基线最小的比值范围。本批真实场景均未跨 1.15；跨阈值的公式分支在明确的临时单测夹具中验证。该范围不是置信区间，false 不证明统计稳定或显著。新增字段与报告只是补充描述，五项历史 verdict 和比值与初始记录逐项一致。

### 负向前提与异常处理

对真实摘要的明确标识副本构造五类：只保留四条样本、基线与当前 run_id 重叠、complete=false、input_id 改变、environment 改变，均返回 unable_to_compare。派生拒绝场景不增加“真实测量数”，没有改写 result.json。

对 GNU time 的空文件/非有限值/缺列/负指标，及缺少实际 cpu.max、父级控制器证据的情况增加拒绝测试；没有用默认零掩盖缺失。原生工具正常场景全部通过，不代表已完成它们的失败/超时/权限场景横向验收。

## 证据与复建

- [归档](../../evidence/comparison/comparison-openeuler-20261117.tar.gz)，[SHA256 清单](../../evidence/comparison/SHA256SUMS)。
- `results/tools/`：输入/独立参考元数据、版本、comparison.jsonl、汇总，以及每次本队或原生调用的原始文件。
- `results/regression/`：预声明计划、六个完整 A 实验、correctness.json、原始规则输出、附加敏感性 HTML。
- `work/validation/`：两轮测试日志、取证检查脚本及输出、环境/依赖、源码/构建信息、最终提交与工作树状态。结束时 osdesign-* 单元列表为空。
- 大 input.csv 不在归档内，可用相同生成器/参数重新生成并核对哈希；未包含第三方 GNU 源码/二进制、凭据或虚拟机镜像。运行当时的绝对路径保持原样。
- 本机展开副本在 `results/comparison-20261117/`（Git 忽略）；共享证据仅为上述归档。

## 阶段结论与限制

本轮新增 **84 次实际执行、72 条非预热测量与 12 条被排除预热**，输出和资源/清理检查均通过。有限的健康对照未触发信号，明显额外工作量触发信号，样本不足/不兼容拒绝比较；这不构成普遍误报/漏报率、统计功效、生产性能、根因或独特创新性的证明。

还需非实现者复验、更多机器/波动与阈值附近样本、其他完整框架的适用性对照、浏览器视觉验收、视频/PPT与比赛流程。代码/证据本地提交，不自动推送、建 PR、共享合并或正式赛事提交。

## 固定样本集阈值检出矩阵（任务 2）

对上述 48 次真实记录重新读取、核验 stdout 哈希和既有独立正确性证据，再用未修改的 compare() 分别传入 10%/15%/25%。这是事后敏感性分析；正式默认仍为预设 15%，没有据此调参。行是额外工作量，**不是实测 wall 增长百分比**。每格括号为基线/当前非预热样本数，两组健康复测分别展示，不合并共享基线。

| 额外工作量 | 阈值 10% | 阈值 15% | 阈值 25% |
|---|---|---|---|
| 0% 健康复测1 | no_threshold_signal (7/7) | no_threshold_signal (7/7) | no_threshold_signal (7/7) |
| 0% 健康复测2 | no_threshold_signal (7/7) | no_threshold_signal (7/7) | no_threshold_signal (7/7) |
| 5% | no_threshold_signal (7/7) | no_threshold_signal (7/7) | no_threshold_signal (7/7) |
| 15% | slowdown_needs_review (7/7) | slowdown_needs_review (7/7) | no_threshold_signal (7/7) |
| 25% | slowdown_needs_review (7/7) | slowdown_needs_review (7/7) | slowdown_needs_review (7/7) |

[逐格 run_id、比值和理由](../../evidence/comparison/threshold-matrix-20261117.json)绑定原始归档 SHA256；每个 run_id 对应归档 results/regression/场景/experiment/run_id/result.json。预热不进入比较，未新增测量。所有格子均满足兼容前提，故未出现 unable_to_compare；其拒绝分支另见上述负向检查。

补充对照：较早两百万行 --passes 2 的三档中位数比为 1.9213/1.9215/2.0565，原预设 15% 均提示复核，见[初轮原始验证](pipeline-validation.md#历史复核规则检查)，与本表不同输入，不混合样本。

这是固定样本集的观察，不是普遍准确率、统计显著性、误报/漏报率或阈值最优性验收；25% 档超过 25% 阈值源于本批实测比值约 1.2557，不能由工作量参数直接推断。

## hyperfine 新增目标机验证（任务 1）

干净测量源码 d8a331e，普通用户目标目录 /home/holo/projects/osdesign-improve01-20261117；openEuler 24.03 LTS-SP4，Python 3.11.6。复用既有报告 venv，pip check 无冲突，未改变运行资源或安全策略。

```bash
PYTHONPATH=src OSDESIGN_INTEGRATION=1 python -m unittest discover -s tests -v
python -m pip check
python experiments/run_pipeline.py --output results/pipeline
python experiments/compare_tools.py --output results/tools --time-binary ~/projects/comparison-tools/time-install/bin/time --hyperfine-binary ~/projects/comparison-tools/hyperfine-1.19.0/hyperfine-v1.19.0-x86_64-unknown-linux-musl/hyperfine
PYTHONPATH=src:. python work/validation/check_improve01.py
```

python 为 ~/projects/osdesign-release-venv-20261117/bin/python。29 项全量测试通过，0 跳过；默认完整流程 18 次最终化（15 测量、3 预热），全部通过原始输出与正确性证据检查。工具对照 **36+18=54 次全部成功**（45 测量、9 预热），逐份独立 SQLite 校验、配额和清理均通过，可见父级一致，输入/负载前后哈希不变。结束时 osdesign-* 单元为零；工作树干净。工具实际版本和哈希、hyperfine 原始 JSON 与逐次 stdout、原始 run 1.1 均已保留。

[新归档](../../evidence/comparison/improve01-openeuler-20261117.tar.gz)与[哈希](../../evidence/comparison/SHA256SUMS)保留 work/validation 检查源码/日志、results/tools 全部原始记录和 results/pipeline；大 CSV 排除，可按 input.json 参数复建。脚本结束后补跑独立核查并再次归档，原始数据未改写。新增记录使用独立 tool-comparison-v1，并记录 hyperfine 参数；不冒充 runner 协议。

批次顺序限制与计时边界见[同类工具说明](../implementation/tool-comparison.md#hyperfine-补充实测任务-12026-11-17)。本轮是代理目标机实测，不是人员验收、框架通用性或统计准确率验收；旧 RC1 PDF/PPT 未重生成，不声称它们已包含本次新增数字。
