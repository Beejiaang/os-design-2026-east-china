import copy
import json
from pathlib import Path
from analysis.core import analyze, compare
from report.html import render
from jsonschema import Draft202012Validator, FormatChecker

root = Path.cwd()
validator = Draft202012Validator(json.loads((root / 'schemas/run-1.1.schema.json').read_text()), format_checker=FormatChecker())
summaries = {}
for name in ('group-first', 'group-healthy', 'group-slow'):
    directory = root / 'results' / name
    summary = analyze(directory / 'experiment')
    assert summary['complete'] and len(summary['eligible']) == 15 and len(summary['excluded']) == 3, summary['issues']
    assert all(g['comparable'] and g['n'] == 5 for g in summary['groups'])
    rows = [json.loads(line) for line in (directory / 'experiment/runs.jsonl').read_text().splitlines()]
    assert len(rows) == 18
    for row in rows:
        validator.validate(row)
        assert row['git_dirty'] == '' and row['cleanup_ok'] is True and row['status'] == 'success'
    summaries[name] = summary
    render(summary, directory / 'report.html')
history = {name: compare(summaries['group-first'], summaries[name]) for name in ('group-healthy', 'group-slow')}
for name, comparison in history.items():
    render(summaries[name], root / 'results' / name / 'history.html', comparison)
for entry in history['group-healthy']['comparisons']:
    assert entry['verdict'] == 'no_threshold_signal', entry
for entry in history['group-slow']['comparisons']:
    assert entry['verdict'] == 'slowdown_needs_review', entry
negative = {}
for field, value in [('input_id', 'different-input'), ('schema_version', 'future'), ('environment', {'fingerprint': 'different'})]:
    changed = copy.deepcopy(summaries['group-healthy'])
    for row in changed['eligible']:
        row[field] = value
    result = compare(summaries['group-first'], changed)
    assert all(entry['verdict'] == 'unable_to_compare' for entry in result['comparisons'])
    negative[field] = result
changed = copy.deepcopy(summaries['group-healthy'])
changed['complete'] = False
result = compare(summaries['group-first'], changed)
assert all(entry['verdict'] == 'unable_to_compare' for entry in result['comparisons'])
negative['incomplete'] = result
(root / 'work/validation/history.json').write_text(json.dumps(history, indent=2))
(root / 'work/validation/negative-checks.json').write_text(json.dumps(negative, indent=2))
print(json.dumps({'validated_final_records':54,'verified_nonwarmup':45,'excluded_warmups':9,
                  'healthy':[r['wall_ratio'] for r in history['group-healthy']['comparisons']],
                  'slow':[r['wall_ratio'] for r in history['group-slow']['comparisons']],
                  'negative_scenarios':list(negative)},indent=2))
