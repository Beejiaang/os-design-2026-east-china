import fs from 'node:fs/promises';
import { PresentationFile, FileBlob } from '@oai/artifact-tool';
const root="C:/Users/Ho'lo/Desktop/2026年操作系统设计赛华东区域赛/os-design-2026-east-china";
const p=await PresentationFile.importPptx(await FileBlob.load(root+'/demo/presentation/答辩材料_RC2.pptx'));
await fs.mkdir(root+'/work/rc2/slides/final',{recursive:true});
for(let i=0;i<p.slides.items.length;i++){const b=await p.export({slide:p.slides.items[i],format:'png',scale:1});await fs.writeFile(root+'/work/rc2/slides/final/slide-'+(i+1)+'.png',new Uint8Array(await b.arrayBuffer()));}
console.log('Rendered '+p.slides.items.length+' final slides');
