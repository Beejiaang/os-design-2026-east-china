$rc2DocPath = (Resolve-Path -LiteralPath 'demo/delivery/设计与测试报告_RC2.docx').Path
$rc2PdfPath = Join-Path (Split-Path -LiteralPath $rc2DocPath) '设计与测试报告_RC2.pdf'
$rc2WordApp = New-Object -ComObject Word.Application
$rc2WordApp.Visible = $false
$rc2WordApp.DisplayAlerts = 0
try {
    $rc2WordDoc = $rc2WordApp.Documents.Open($rc2DocPath, $false, $true)
    $rc2WordDoc.ExportAsFixedFormat($rc2PdfPath, 17)
    $rc2WordDoc.Close(0)
} finally {
    $rc2WordApp.Quit()
}
Write-Output $rc2PdfPath
