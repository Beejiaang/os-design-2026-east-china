from pathlib import Path
import sys,json,hashlib
root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root)]
from analysis.core import analyze
from workloads.dataset import check_output,sha256
from runner.core import source_fingerprint
from experiments.scale_sweep import parse_peak_rss
results=Path('results/scale-sweep')
summary=json.loads((results/'summary.json').read_text());assert summary['complete'] and summary['valid_count']==54
records=[json.loads(s) for s in (results/'runs.jsonl').read_text().splitlines()]
assert len(records)==54 and sum(not r['warmup'] for r in records)==45
for row in records:
 directory=Path(row['artifacts']);expected=json.loads((results/str(row['scale'])/'reference.json').read_text())
 assert row['status']=='success' and row['functional_ok'] and row['cleanup_ok'] and row['quota_verified']
 assert check_output(directory/'stdout.log',expected) and sha256(directory/'stdout.log')==row['stdout_sha256']
 assert parse_peak_rss(directory/'peak-rss.txt')==row['peak_rss_kib']
 assert row['visible_limits'][1:]==records[0]['visible_limits'][1:]
for group in summary['groups']:assert group['n']==5
pipeline=analyze(Path('results/p1/task10/experiment'))
assert pipeline['complete'] and pipeline['finalized_count']==18 and len(pipeline['eligible'])==15
current=source_fingerprint(root/'src')
assert all(r['runner_sha256']==current for r in pipeline['eligible'])
legacy=hashlib.sha256(b''.join(p.read_bytes() for p in sorted(p for package in ('runner','collector') for p in (root/'src'/package).glob('*.py')))).hexdigest()
assert legacy!=current
host=[]
for name in ('task11','task13','task14','task10'):
 directory=root/'results/p1'/name/'experiment';environment=json.loads((directory/'environment.json').read_text());meta=environment['host_load']
 samples=[json.loads(line) for line in (directory/meta['path']).read_text().splitlines()]
 assert len(samples)==meta['samples'] and len(samples)>=2 and not meta['errors']
 assert all(r['loadavg'] is not None and not r['error'] for r in samples)
 assert all(a['monotonic_seconds']<=b['monotonic_seconds'] for a,b in zip(samples,samples[1:]))
 host.append({'scenario':name,'samples':len(samples)})
print(json.dumps({'valid_scale_runs':54,'nonwarmup_scale_runs':45,'default_pipeline_finalized':18,'source_fingerprint_v2':current,'legacy_algorithm_on_same_source':legacy,'host_load':host,'groups':summary['groups']},indent=2))
