工程复验包 RC1 · 源码 9fc805006ea228e930e705319ff171709c770934
从解压目录开始，在 openEuler x86_64、CPython 3.11 和可用的 systemd 用户会话中执行。
project/ 供阅读；下面的命令从包内 Git 历史检出源码，以便记录真实提交。
请在新目录解压。完成后打开 review/results/first/report.html。

```bash
set -eu
git clone --branch feat/a-offline-review-package ./project-9fc805006ea2.bundle review
cd review
test "$(git rev-parse HEAD)" = "9fc805006ea228e930e705319ff171709c770934"
python3 -m venv .venv
. .venv/bin/activate
PIP_NO_INDEX=1 PIP_FIND_LINKS="$PWD/../wheels" python -m pip install -e '.[report]'
python -m pip check
python -m runner doctor
OSDESIGN_INTEGRATION=1 python -m unittest discover -s tests -v
python experiments/run_pipeline.py --output results/first
test -z "$(git status --porcelain)"
```

随包报告和幻灯片的版本见 project/demo/delivery/README.md。人员验收、正式视频与赛事接收状态见项目提交清单。
